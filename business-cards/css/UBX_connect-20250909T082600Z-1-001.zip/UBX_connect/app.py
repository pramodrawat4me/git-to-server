# app.py
import qrcode
import io
from flask import send_file, request
from flask import Flask, render_template, url_for

app = Flask(__name__)

@app.route('/qr/<person>')
def generate_qr(person):
    # Determine URL to encode
    if person == "arnav":
        profile_url = request.url_root.rstrip('/') + '/'
    elif person == "maneesh":
        profile_url = request.url_root.rstrip('/') + '/maneesh'
    else:
        return "Invalid profile", 404

    # Generate QR code in memory
    img = qrcode.make(profile_url)
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)

    return send_file(buf, mimetype='image/png')

@app.route('/')
def arnav():
    # Data to fill into profile.html
    name = "Arnav Awasthi"
    role = "COO & Co-founder at UnBound X"
    avatar_filename = "arnav.png"
    social_links = [
        {"url": "https://www.linkedin.com/in/arnavunbound/", "icon": "linkedin"},
        {"url": "mailto:arnav@unboundxinc.com",        "icon": "email"},
        {"url": "https://instagram.com/unboundxapp","icon": "instagram"},
        {"url": url_for('generate_qr', person='arnav'), "icon": "qr"} 
    ]
    tabs = [
        {
            "url":   "https://unboundx.co",
            "label": "Visit our website",
            "icon_filename": "globe.svg",
        },
        {
            "url":   "https://ubverse.unboundx.co",
            "label": "Visit UBverse",
            "icon_filename": "qr-code.svg",
        },
        {
            "url":   "/",
            "label": "Download our Investor Deck!",
            "icon_filename": "folder-cloud.svg",
        },
        {
            "url":   "https://apps.apple.com/us/app/unbound-x/id6745837250",
            "label": "Download UnBound X via App Store",
            "icon_filename": "apple.svg",
        },
        {
            "url":   "https://play.google.com/store/apps/details?id=com.unboundx",
            "label": "Download UnBound X via Google Play",
            "icon_filename": "google.svg",
        },
    ]

    return render_template(
        "profile.html",
        name=name,
        role=role,
        avatar_filename=avatar_filename,
        social_links=social_links,
        tabs=tabs,
        vcard_filename="vcards/arnav.vcf",
    )
@app.route('/maneesh')
def maneesh():
    name = "Maneesh Awasthi"
    role = "CEO & Co-founder at UnBound X"
    avatar_filename = "maneesh.jpg"
    social_links = [
        {"url": "https://www.linkedin.com/in/maneeshawasthi/", "icon": "linkedin"},
        {"url": "mailto:maneesh.awasthi@unboundxinc.com", "icon": "email"},
        {"url": "https://instagram.com/unboundxapp", "icon": "instagram"},
        {"url": "https://x.com/unboundxapp", "icon": "x"},
        {"url": url_for('generate_qr', person='maneesh'), "icon": "qr"}
    ]
    tabs = [
        {
            "url":   "https://unboundx.co",
            "label": "Visit our website",
            "icon_filename": "globe.svg",
        },
        {
            "url":   "https://ubverse.unboundx.co",
            "label": "Visit UBverse",
            "icon_filename": "qr-code.svg",
        },
        {
            "url":   "/",
            "label": "Download our Investor Deck!",
            "icon_filename": "folder-cloud.svg",
        },
        {
            "url":   "https://apps.apple.com/us/app/unbound-x/id6745837250",
            "label": "Download UnBound X via App Store",
            "icon_filename": "apple.svg",
        },
        {
            "url":   "https://play.google.com/store/apps/details?id=com.unboundx",
            "label": "Download UnBound X via Google Play",
            "icon_filename": "google.svg",
        },
    ]

    return render_template(
        "profile.html",
        name=name,
        role=role,
        avatar_filename=avatar_filename,
        social_links=social_links,
        tabs=tabs,
        vcard_filename="vcards/maneesh.vcf",
    )

if __name__ == '__main__':
    app.run(debug=True)
